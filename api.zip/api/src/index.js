import './db/mongoose'
import express from 'express'
import bodyparser from 'body-parser'

import authentication from './routes/authentication'
import company from './routes/company'
import buyer from './routes/buyer'
import order from './routes/order'
import draft from './routes/draft'

const app = express()

// Middlewares
app.use(bodyparser.json())

// Only on development environment
// if (process.env.NODE_ENV !== 'production') {
//   import cors from 'cors'
//   import logger from 'morgan'
//   app.use(logger('dev'))
//   app.use(cors())
// }

app.use(authentication, company, buyer, draft, order)

// Server Config
const port = 3000

app.listen(port, () => {
  console.clear()
  console.log(
    `> Server started and running on port: ${port} \n----------------------------------------`,
  )
})
